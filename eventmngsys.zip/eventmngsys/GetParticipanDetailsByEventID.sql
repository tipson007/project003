Create Procedure GetParticipanDetailsByEventID (@evnetid int)
As
Begin
Select P.participant_first_name,participant_last_name,E.event_id,E.event_name,E.event_location
from Participant as P inner join EventTable as E on P.participant_id = E.participant_id
where event_Id= '100';
End;