USE [EventMgmtDatabase]
GO

/****** Object:  Table [dbo].[Participant]    Script Date: 17-Apr-18 3:36:31 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Participant](
	[participant_id] [varchar](50) NOT NULL,
	[participant_first_name] [varchar](50) NOT NULL,
	[participant_last_name] [varchar](50) NOT NULL,
	[participant_contact_number] [varchar](50) NOT NULL,
 CONSTRAINT [PK_Participant] PRIMARY KEY CLUSTERED 
(
	[participant_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


