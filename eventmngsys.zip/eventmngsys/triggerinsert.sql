
USE [EventMgmtDatabase]
GO

/****** Object:  View [dbo].[EventAndSponsorNames]    Script Date: 16-Apr-18 9:15:26 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

Create Trigger updateseats on Ticket 
After Insert , Update 
As 
Begin 
update P1 set p1.venue_capacity = P1.venue_capacity -1
from [Venue] as P1;
End;

create view [dbo].[PriceFromEventID]
as select t.price, t.ticket_Id, e.event_name,e.event_time
from EventTable as e inner join Ticket as t
on e.event_Id=t.Event_Id
GO

use [EventMgmtDatabase]

Create trigger Delete_Bookings
ON Ticket
INSTEAD OF DELETE 
As begin
Print ('Sorry, the data from Bookings table can not be deleted')
end
select * from Ticket
select*from PriceFromEventID

Delete Ticket;


select * from venue;
