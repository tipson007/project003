Create trigger Delete_Bookings
ON Bookings
INSTEAD OF DELETE 
As begin
Print ('Sorry, the data from Bookings table can not be deleted')
end

where is your report?