USE [EventMgmtDatabase]
GO

/****** Object:  Table [dbo].[Ticket]    Script Date: 17-Apr-18 3:37:31 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Ticket](
	[ticket_Id] [int] NOT NULL,
	[Type] [varchar](40) NULL,
	[ticket_number] [varchar](40) NULL,
	[ticket_sold] [varchar](50) NULL,
	[ticket_notsold] [varchar](50) NULL,
	[price] [money] NULL,
	[event_id] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[ticket_Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Ticket]  WITH CHECK ADD FOREIGN KEY([event_id])
REFERENCES [dbo].[EventTable] ([event_Id])
GO


