USE [EventMgmtDatabase]
GO

/****** Object:  Table [dbo].[Venue]    Script Date: 17-Apr-18 3:37:49 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Venue](
	[venue_Id] [int] NOT NULL,
	[Type] [varchar](40) NULL,
	[venue_hall] [varchar](40) NULL,
	[venue_capacity] [varchar](50) NULL,
	[venue_location] [varchar](50) NULL,
	[event_id] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[venue_Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Venue]  WITH CHECK ADD FOREIGN KEY([event_id])
REFERENCES [dbo].[EventTable] ([event_Id])
GO


