USE [EventMgmtDatabase]
GO

/****** Object:  View [dbo].[EventAndSponsorNames]    Script Date: 17-Apr-18 3:48:05 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create view [dbo].[EventAndSponsorNames]
as select c.event_name, c.event_location, a.sponsor_name,a.company_name
from EventTable as c inner join sponsor as a
on C.event_Id=a.Event_Id
GO


