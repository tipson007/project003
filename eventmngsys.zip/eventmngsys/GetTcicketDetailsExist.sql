Use [EventMgmtDatabase]
go
	create procedure GetXMLDocument(@eventid int)
	AS
	begin
	select event_location from EventTable
	where event_id =@eventid;
	End;
	
	