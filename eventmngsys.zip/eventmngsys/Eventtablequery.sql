USE [EventMgmtDatabase]
GO

/****** Object:  Table [dbo].[EventTable]    Script Date: 17-Apr-18 3:34:57 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[EventTable](
	[event_Id] [int] NOT NULL,
	[Type] [varchar](40) NULL,
	[event_name] [varchar](60) NULL,
	[event_time] [varchar](40) NULL,
	[event_location] [xml] NULL,
	[participant_id] [varchar](50) NULL,
	[sponsor_Id] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[event_Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[EventTable]  WITH CHECK ADD FOREIGN KEY([participant_id])
REFERENCES [dbo].[Participant] ([participant_id])
GO

ALTER TABLE [dbo].[EventTable]  WITH CHECK ADD FOREIGN KEY([sponsor_Id])
REFERENCES [dbo].[sponsor] ([sponsor_Id])
GO


