Use [EventMgmtDatabase]
GO
create Procedure GetCountofBookings (@eventid int)
AS Begin
select count(ticket_Id) from Ticket where event_id = @eventid;
End;	

select * from Ticket