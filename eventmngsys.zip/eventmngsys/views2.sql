USE [EventMgmtDatabase]
GO

/****** Object:  View [dbo].[PriceFromEventID]    Script Date: 17-Apr-18 3:48:36 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create view [dbo].[PriceFromEventID]
as select t.price, t.ticket_Id, e.event_name,e.event_time
from EventTable as e inner join Ticket as t
on e.event_Id=t.Event_Id

GO


