select * from Bookings
Create Procedure GetVenueDetailsByEventID (@evnetid int)
As
Begin
Select v.venue_id,v.venue_location,v.venue_hall,E.event_id,E.event_name,E.event_location
from Venue as V inner join EventTable as E on V.event_id = E.event_Id
where v.event_id= @evnetid;
End;

select * from Venue
select * from Venue
	select * from Ticket
	select * from EventTable